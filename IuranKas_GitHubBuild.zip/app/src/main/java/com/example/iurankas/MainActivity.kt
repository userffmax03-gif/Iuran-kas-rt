package com.example.iurankas

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.*

data class Member(var name:String, var arrears:Int=0, var present:Boolean=true)

class MainActivity : Activity() {
    private val members = mutableListOf<Member>()
    private var fee = 10000
    private var cash = 0
    private var totalIn = 0
    private var totalOut = 0
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id","ID"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        for (n in listOf("Agha Baby Spa","Agus Setya Nugraha","Agus Wantro","Anggota 4","Anggota 5","Anggota 6","Anggota 7","Anggota 8"))
            members.add(Member(n))
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        val title=TextView(this).apply { text="IURAN KAS"; textSize=26f; gravity=Gravity.CENTER; setTextColor(Color.rgb(21,101,192)); setPadding(0,0,0,16) }
        root.addView(title)
        val feeRow=LinearLayout(this)
        feeRow.addView(TextView(this).apply{text="Iuran rutin: "; textSize=18f})
        val feeEdit=EditText(this).apply{setText("10000"); inputType=2}
        feeRow.addView(feeEdit, LinearLayout.LayoutParams(0,60,1f))
        val saveFee=Button(this).apply{text="Simpan"}
        feeRow.addView(saveFee); root.addView(feeRow)
        saveFee.setOnClickListener { fee=feeEdit.text.toString().toIntOrNull()?:10000; refresh() }

        summary=TextView(this).apply{textSize=17f; setPadding(0,12,0,12)}
        root.addView(summary)

        val addOut=Button(this).apply{text="💸 Tambah Uang Keluar"}
        root.addView(addOut)
        addOut.setOnClickListener { addExpense() }

        val scroll=ScrollView(this)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        summary.text="Saldo: ${rupiah.format(cash)}\nUang masuk: ${rupiah.format(totalIn)}   |   Uang keluar: ${rupiah.format(totalOut)}"
        list.removeAllViews()
        members.forEachIndexed { i,m ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL; setPadding(0,6,0,6)}
            row.addView(TextView(this).apply{text="${i+1}. ${m.name}"; textSize=16f}, LinearLayout.LayoutParams(0,70,1f))
            val status=Button(this).apply{text=if(m.present)"HADIR" else "TIDAK HADIR"}
            row.addView(status)
            val pay=Button(this).apply{text="Bayar\n${rupiah.format(if(m.present)(m.arrears+1)*fee else 0)}"}
            row.addView(pay)
            status.setOnClickListener { m.present=!m.present; refresh() }
            pay.setOnClickListener {
                if(m.present){
                    val amount=(m.arrears+1)*fee
                    totalIn+=amount; cash+=amount; m.arrears=0; refresh()
                }
            }
            list.addView(row)
            if(!m.present) m.arrears++
        }
    }

    private fun addExpense() {
        val input=EditText(this).apply{hint="Nominal pengeluaran"; inputType=2}
        AlertDialog.Builder(this).setTitle("Uang Keluar").setView(input)
            .setPositiveButton("Simpan"){_,_-> val x=input.text.toString().toIntOrNull()?:0; totalOut+=x; cash-=x; refresh()}
            .setNegativeButton("Batal",null).show()
    }
}