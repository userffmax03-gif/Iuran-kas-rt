# Iuran Kas Android
Aplikasi sederhana untuk iuran rutin dan kas.
Aturan pembayaran: (jumlah tunggakan + 1) x iuran rutin.
Hadir dan membayar -> tunggakan kembali 0.
Tidak hadir -> tunggakan bertambah pada pertemuan berikutnya.
Kas menghitung uang masuk, uang keluar, dan saldo.
Buka proyek ini dengan Android Studio, lalu Build APK.
